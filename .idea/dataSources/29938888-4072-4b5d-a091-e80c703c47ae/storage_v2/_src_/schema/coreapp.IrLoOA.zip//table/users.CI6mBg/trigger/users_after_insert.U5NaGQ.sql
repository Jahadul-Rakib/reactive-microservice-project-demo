create definer = root@`%` trigger users_after_insert
    after insert
    on users
    for each row
BEGIN
INSERT INTO ob_bounty_accounts
(owner_id, silver_coin)
VALUES
(NEW.id,100);
END;

