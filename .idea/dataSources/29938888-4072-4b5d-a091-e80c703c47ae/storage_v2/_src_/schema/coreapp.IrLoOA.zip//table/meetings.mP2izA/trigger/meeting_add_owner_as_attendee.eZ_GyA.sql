create definer = root@`%` trigger meeting_add_owner_as_attendee
    after insert
    on meetings
    for each row
BEGIN
INSERT INTO meeting_attendees
(confirmed, meeting_id, project_id, user_id)
VALUES
('YES',NEW.id, NEW.project_id, NEW.owner_id);
END;

