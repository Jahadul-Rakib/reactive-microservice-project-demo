create definer = root@`%` event bounty_cleanup on schedule
    every '1' MONTH
        starts '2019-09-01 00:00:00'
    enable
    do
    BEGIN
    INSERT INTO ob_bounty_balance (
        silver_coin, gold_coin, platinum_coin, owner_id, balance_date
    )
    SELECT
        silver_coin, gold_coin, platinum_coin, owner_id, SUBDATE(CURRENT_DATE(), INTERVAL 1 DAY)
    FROM
        ob_bounty_accounts;

    UPDATE ob_bounty_accounts SET silver_coin=100, gold_coin=0, platinum_coin=0;
END;

