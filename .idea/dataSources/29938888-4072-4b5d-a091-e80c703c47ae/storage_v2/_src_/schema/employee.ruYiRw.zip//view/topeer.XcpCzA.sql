create view topeer as
select max(`employee`.`student`.`s_markes`) AS `max(s_markes)`
from `employee`.`student`;

